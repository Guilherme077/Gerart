package com.gerartweb.gerart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerartApplicationTests {

	@Test
	void contextLoads() {
	}

}
