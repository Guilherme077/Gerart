package com.gerartweb.gerart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerartApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerartApplication.class, args);
	}

}
